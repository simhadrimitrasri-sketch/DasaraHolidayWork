# Mitra Sri | Student Portfolio

A student portfolio for a first-year B.Tech CSE learner.

Built with HTML5, CSS3 and JavaScript. Open `index.html` in a modern browser. Front-end prototype only; no backend or persistent data.
