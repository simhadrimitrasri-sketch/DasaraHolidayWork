# Student Academic Dashboard

A responsive dashboard prototype for academic information.

Built with HTML5, CSS3 and JavaScript. Open `index.html` in a modern browser. Front-end prototype only; no backend or persistent data.
