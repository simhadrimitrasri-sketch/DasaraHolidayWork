# Screenshot checklist
Capture real browser screenshots after opening each index.html: portfolio, college information portal, and academic dashboard. Save screenshots in this folder. Do not describe mockups as actual browser screenshots.
