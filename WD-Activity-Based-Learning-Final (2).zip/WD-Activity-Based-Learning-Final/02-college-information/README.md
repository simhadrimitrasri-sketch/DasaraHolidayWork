# College Information Portal

A sample information portal for campus life and admission guidance.

Built with HTML5, CSS3 and JavaScript. Open `index.html` in a modern browser. Front-end prototype only; no backend or persistent data.
