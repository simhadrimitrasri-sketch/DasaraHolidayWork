# WD-Activity-Based-Learning
**Student:** Mitra Sri  
**Roll number:** [Enter your roll number]  
**Branch:** B.Tech Computer Science and Engineering  
**Year/section:** First Year / [Enter your section]  
**Institution:** Dr. RVR & NRI Institute of Technology

## Selected case studies
1. Personal Portfolio Website
2. College Information and Admissions Website
3. Student Academic Dashboard

## Technologies
HTML5, CSS3, JavaScript, responsive layouts, semantic sections, form controls and media queries.

## Run
Open each project's `index.html` in Chrome or another modern browser.

## Limitations
These are front-end educational prototypes. Forms do not send data to a server. Academic figures and institutional information are sample content and must be verified or replaced before submission.
